from django.shortcuts import render

# Create your views here.
def free_course(request):
    return render(request,'resources/freecourse.html', {'fcrs':5, 'platform':'S.H.Linkon'})

def blog(request):
    course1 = 'Machine Learning'
    course2 = 'Deep Learning'
    course3 = 'data analysis'
    course4 = 'Python with problem solving'
    freecourse_details={'c1':course1, 'c2':course2, 'c3':course3, 'c4':course4}
    return render(request,'resources/blog.html', freecourse_details)